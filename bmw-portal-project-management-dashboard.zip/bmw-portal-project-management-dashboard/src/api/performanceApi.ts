// src/api/performanceApi.ts

export type PerformanceSnapshot = {
  product: string;
  provider: string;
  updatedAt: string | null;
  data: any;
  lastError?: string | null;
};

async function json<T>(r: Response): Promise<T> {
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = (data && (data.error || data.message)) || `HTTP ${r.status}`;
    throw new Error(msg);
  }
  return data as T;
}

// ✅ backend eski/yeni response formatlarını tek formata çevirir
function normalizeSnapshotResponse(product: string, res: any): PerformanceSnapshot {
  // NEW format (ideal): { ok, product, provider, updatedAt, data, lastError }
  if (res && (res.provider || res.updatedAt || res.data) && !res.cache) {
    return {
      product,
      provider: res.provider || "mock",
      updatedAt: res.updatedAt ?? null,
      data: res.data ?? null,
      lastError: res.lastError ?? null,
    };
  }

  // OLD format: { ok, cache: { provider, updatedAt, data, lastError } }
  if (res?.cache) {
    const cache = res.cache;
    const picked = product ? (cache?.data ? cache.data[product] : null) : cache?.data || null;

    return {
      product,
      provider: cache?.provider || "mock",
      updatedAt: cache?.updatedAt ?? null,
      data: picked,
      lastError: cache?.lastError ?? null,
    };
  }

  // fallback
  return {
    product,
    provider: "mock",
    updatedAt: null,
    data: null,
    lastError: null,
  };
}

export async function getPerformanceSnapshot(product: string): Promise<PerformanceSnapshot> {
  const r = await fetch(`/api/performance/snapshot?product=${encodeURIComponent(product)}`);
  const res: any = await json<any>(r);
  return normalizeSnapshotResponse(product, res);
}

// NOTE: backend refresh şu an product bazlı değil (scheduler tüm ürünleri çekiyor).
export async function refreshPerformance(_product: string): Promise<PerformanceSnapshot> {
  const r = await fetch(`/api/performance/refresh`, { method: "POST" });
  const res: any = await json<any>(r);
  return normalizeSnapshotResponse(_product, res);
}

export async function refreshPerformanceAll(): Promise<void> {
  const r = await fetch(`/api/performance/refresh-all`, { method: "POST" });
  await json(r);
}

export async function getPerformanceConfig(): Promise<any> {
  const r = await fetch(`/api/performance/config`);
  const res: any = await json<any>(r);
  return res?.config ?? res; // ✅
}

export async function updatePerformanceConfig(payload: any): Promise<any> {
  const r = await fetch(`/api/performance/config`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const res: any = await json<any>(r);
  return res?.config ?? res; // ✅
}