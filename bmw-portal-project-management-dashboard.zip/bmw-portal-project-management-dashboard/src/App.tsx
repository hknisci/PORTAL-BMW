// src/App.tsx
import React from "react";

export default function App() {
  return (
    <div style={{ padding: 16, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial" }}>
      <h1 style={{ margin: 0, fontSize: 18 }}>BMW Portal Dashboard</h1>
      <p style={{ marginTop: 8, color: "#6b7280" }}>
        App entry is wired. Replace this component with your actual layout/router when ready.
      </p>
    </div>
  );
}